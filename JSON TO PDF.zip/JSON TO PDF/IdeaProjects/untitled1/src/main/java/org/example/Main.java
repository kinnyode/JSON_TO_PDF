package org.example;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import org.json.JSONObject;
import com.itextpdf.text.Font;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Element;


public class Main {

    public static void main(String[] args) {
        String jsonUrl = "http://api.issl.ng:7777/ibank/api/v1/getCustomerDetailsv4?CustomerNo=0001"; // Replace with your JSON URL

        try {
            String jsonString = readJsonFromUrl(jsonUrl);
            JSONObject jsonObject = new JSONObject(jsonString);
            generatePdfFromJson(jsonObject, "output.pdf");
            System.out.println("PDF created successfully.");
        } catch (IOException | com.itextpdf.text.DocumentException e) {
            e.printStackTrace();
        }
    }
    public static String readJsonFromUrl(String urlString) throws IOException {
        URL url = new URL(urlString);
        HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
        httpURLConnection.setRequestMethod("GET");
        httpURLConnection.setRequestProperty("Accept", "application/json");

        int responseCode = httpURLConnection.getResponseCode();
        if (responseCode == HttpURLConnection.HTTP_OK) {
            try (InputStream inputStream = httpURLConnection.getInputStream();
                 InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                 BufferedReader bufferedReader = new BufferedReader(inputStreamReader)) {

                StringBuilder stringBuilder = new StringBuilder();
                String inputLine;
                while ((inputLine = bufferedReader.readLine()) != null) {
                    stringBuilder.append(inputLine);
                }
                return stringBuilder.toString();
            }
        } else {
            throw new IOException("Failed to fetch JSON data from URL. Response code: " + responseCode);
        }
    }

    public static void generatePdfFromJson(JSONObject jsonObject, String outputPath) throws DocumentException, IOException {
        Document document = new Document();
        PdfWriter.getInstance(document, new FileOutputStream(outputPath));
        document.open();


        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 22);
        Paragraph title = new Paragraph("AUTHORIZED SIGNATORY", titleFont);

        title.setAlignment(Element.ALIGN_LEFT);
        document.add(title);


        Font boldFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12);
        Font regularFont = FontFactory.getFont(FontFactory.HELVETICA, 10);

        document.add(new Paragraph("\n"));



        document.add(new Paragraph("Title: " + jsonObject.get("nokTitle")));
        document.add(new Paragraph("First Name: " + jsonObject.get("shortName")));
        document.add(new Paragraph("Middle Name: " + jsonObject.get("lastName")));
        document.add(new Paragraph("Surname: " + jsonObject.get("otherName")));
        document.add(new Paragraph("Date of Birth: " + jsonObject.get("nokTitle")));
        document.add(new Paragraph("Nationality: " + jsonObject.get("nationality")));
        document.add(new Paragraph("State of Origin: " + jsonObject.get("stateOfOrigin")));
        document.add(new Paragraph("Local Govt: " + jsonObject.get("lgaOfResidence")));
        document.add(new Paragraph("Religion: " + jsonObject.get("religion")));
        document.add(new Paragraph("Mother's Maiden Name: " + jsonObject.get("mothersMaidenName")));
        document.add(new Paragraph("Residential Address: " + jsonObject.get("address1Line1")));
        document.add(new Paragraph("Phone: " + jsonObject.get("phoneRef")));
        document.add(new Paragraph("Email: " + jsonObject.get("nokEmailAddress")));
        document.add(new Paragraph("ID Type: " + jsonObject.get("bvn")));
        document.add(new Paragraph("ID Number: " + jsonObject.get("id")));
        document.add(new Paragraph("Occupation/Employer: " + jsonObject.get("occupationCode")));
        document.add(new Paragraph("Source Of Income: " + jsonObject.get("grossAnnualIncome")));
        document.add(new Paragraph("Signature : " + jsonObject.get("nokEmailAddress")));
        document.add(new Paragraph("BVN: " + jsonObject.get("memberShipNo")));


        document.close();
    }
}
