import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

public class Main {

    public static void main(String[] args) {
        String jsonUrl = "http://api.issl.ng:7777/ibank/api/v1/getCustomerDetailsv4?CustomerNo=0001"; // Replace with your JSON URL

        try {
            String jsonString = readJsonFromUrl(jsonUrl);
            JSONObject jsonObject = new JSONObject(jsonString);
            generatePdfFromJson(jsonObject, "output.pdf");
            System.out.println("PDF created successfully.");
        } catch (IOException | com.itextpdf.text.DocumentException e) {
            e.printStackTrace();
        }
    }

    public static String readJsonFromUrl(String urlString) throws IOException {
        URL url = new URL(urlString);
        HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
        httpURLConnection.setRequestMethod("GET");
        httpURLConnection.setRequestProperty("Accept", "application/json");

        int responseCode = httpURLConnection.getResponseCode();
        if (responseCode == HttpURLConnection.HTTP_OK) {
            try (InputStream inputStream = httpURLConnection.getInputStream();
                 InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                 BufferedReader bufferedReader = new BufferedReader(inputStreamReader)) {

                StringBuilder stringBuilder = new StringBuilder();
                String inputLine;
                while ((inputLine = bufferedReader.readLine()) != null) {
                    stringBuilder.append(inputLine);
                }
                return stringBuilder.toString();
            }
        } else {
            throw new IOException("Failed to fetch JSON data from URL. Response code: " + responseCode);
        }
    }

    // ... (rest of the code remains unchanged)

}
