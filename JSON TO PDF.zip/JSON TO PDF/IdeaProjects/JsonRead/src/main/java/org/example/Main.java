import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;

import java.io.IOException;

public class PdfCreator {

    public static void main(String[] args) {
        String outputFilePath = "output.pdf";

        try {
            // Create a new PDF document
            PDDocument document = new PDDocument();
            PDPage page = new PDPage();
            document.addPage(page);

            // Start writing content to the PDF
            PDPageContentStream contentStream = new PDPageContentStream(document, page);
            contentStream.beginText();
            contentStream.newLineAtOffset(100, 700); // Set the starting position for text

            // Fill the PDF with values
            contentStream.showText("Name: John Doe");
            contentStream.newLineAtOffset(0, -20); // Move to the next line
            contentStream.showText("Age: 30");
            // Add more fields as needed...

            contentStream.endText();
            contentStream.close();

            // Save the PDF document
            document.save(outputFilePath);
            document.close();

            System.out.println("PDF created successfully!");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
